# kotiheating-android
![RemoteControlLauncher](./app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png "RemoteControlLauncher")&nbsp;<br/>
Android client for kotiheating-arduino  
  
![RemoteControlMain](./extras/screens/kh_main.png "RemoteControlMain")&nbsp;
![RemoteControlQuickOption](./extras/screens/kh_quick_option.png "RemoteControlQuickOption") &nbsp;
![RemoteControlUser](./extras/screens/kh_user.png "RemoteControlUser")&nbsp;<br/><br/>

