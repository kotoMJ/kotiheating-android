package common.log

import android.util.Log


fun logk(string: String) = Log.e("TAG", string)